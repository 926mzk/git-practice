# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '26e71c08461092e68ea8a8faeb2d3eedc21fe91e35bb92bc5144881611940f1afbe24895f10d67fc4a3b218a46ac7a81a3caf2a9e39e31372d2624de6f18fd07'